import { HistoricalEvent, HistoricalFigure, QuizQuestion, Region, TimelinePeriod } from '../types';

export const timelinePeriods: TimelinePeriod[] = [
  {
    id: 'prehistoric',
    name: 'Prehistoric Era',
    startYear: -3500000,
    endYear: -3000,
    color: '#8B4513',
    events: [
      {
        id: 'fire',
        title: 'Control of Fire',
        date: '1.5 million years ago',
        year: -1500000,
        description: 'Early humans learn to control fire, revolutionizing cooking, warmth, and protection.',
        category: 'invention',
        region: 'Africa',
        importance: 5
      },
      {
        id: 'agriculture',
        title: 'Agricultural Revolution',
        date: '10,000 BCE',
        year: -10000,
        description: 'Humans begin domesticating plants and animals, leading to permanent settlements.',
        category: 'invention',
        region: 'Fertile Crescent',
        importance: 5
      },
      {
        id: 'wheel',
        title: 'Invention of the Wheel',
        date: '3500 BCE',
        year: -3500,
        description: 'The wheel is invented in Mesopotamia, revolutionizing transportation and pottery.',
        category: 'invention',
        region: 'Mesopotamia',
        importance: 4
      }
    ]
  },
  {
    id: 'ancient',
    name: 'Ancient Era',
    startYear: -3000,
    endYear: 500,
    color: '#D4AF37',
    events: [
      {
        id: 'writing',
        title: 'Invention of Writing',
        date: '3200 BCE',
        year: -3200,
        description: 'Cuneiform script developed in Mesopotamia, marking the beginning of recorded history.',
        category: 'invention',
        region: 'Mesopotamia',
        importance: 5
      },
      {
        id: 'pyramid',
        title: 'Great Pyramid of Giza',
        date: '2580 BCE',
        year: -2580,
        description: 'The Great Pyramid is built as a tomb for Pharaoh Khufu, becoming one of the Seven Wonders.',
        category: 'empire',
        region: 'Egypt',
        importance: 5
      },
      {
        id: 'hammurabi',
        title: 'Code of Hammurabi',
        date: '1750 BCE',
        year: -1750,
        description: 'One of the earliest and most complete legal codes, establishing the principle of justice.',
        category: 'empire',
        region: 'Babylon',
        importance: 4
      },
      {
        id: 'exodus',
        title: 'The Exodus',
        date: '1300 BCE',
        year: -1300,
        description: 'Moses leads the Israelites out of Egypt, foundational event in Jewish history.',
        category: 'culture',
        region: 'Egypt/Sinai',
        importance: 4
      },
      {
        id: 'trojan-war',
        title: 'Trojan War',
        date: '1200 BCE',
        year: -1200,
        description: 'Legendary war between Greeks and Trojans, immortalized in Homer\'s Iliad.',
        category: 'war',
        region: 'Troy',
        importance: 3
      },
      {
        id: 'olympics',
        title: 'First Olympic Games',
        date: '776 BCE',
        year: -776,
        description: 'The first recorded Olympic Games held in Olympia, Greece.',
        category: 'culture',
        region: 'Greece',
        importance: 3
      },
      {
        id: 'rome-founded',
        title: 'Founding of Rome',
        date: '753 BCE',
        year: -753,
        description: 'According to legend, Rome is founded by Romulus and Remus.',
        category: 'empire',
        region: 'Italy',
        importance: 4
      },
      {
        id: 'buddha',
        title: 'Birth of Buddha',
        date: '563 BCE',
        year: -563,
        description: 'Siddhartha Gautama (Buddha) is born, later founding Buddhism.',
        category: 'culture',
        region: 'India',
        importance: 4
      },
      {
        id: 'confucius',
        title: 'Birth of Confucius',
        date: '551 BCE',
        year: -551,
        description: 'Chinese philosopher Confucius is born, his teachings shape Chinese culture.',
        category: 'culture',
        region: 'China',
        importance: 4
      },
      {
        id: 'persian-empire',
        title: 'Persian Empire Founded',
        date: '550 BCE',
        year: -550,
        description: 'Cyrus the Great establishes the Persian Empire, the largest empire of its time.',
        category: 'empire',
        region: 'Persia',
        importance: 4
      },
      {
        id: 'democracy',
        title: 'Athenian Democracy',
        date: '508 BCE',
        year: -508,
        description: 'Cleisthenes establishes democracy in Athens, the world\'s first democratic system.',
        category: 'empire',
        region: 'Greece',
        importance: 5
      },
      {
        id: 'marathon',
        title: 'Battle of Marathon',
        date: '490 BCE',
        year: -490,
        description: 'Greeks defeat the Persians at Marathon, preserving Greek independence.',
        category: 'war',
        region: 'Greece',
        importance: 4
      },
      {
        id: 'thermopylae',
        title: 'Battle of Thermopylae',
        date: '480 BCE',
        year: -480,
        description: '300 Spartans make their legendary last stand against the Persian army.',
        category: 'war',
        region: 'Greece',
        importance: 4
      },
      {
        id: 'golden-age',
        title: 'Golden Age of Athens',
        date: '461-429 BCE',
        year: -461,
        description: 'Athens reaches its cultural and political peak under Pericles.',
        category: 'culture',
        region: 'Greece',
        importance: 4
      },
      {
        id: 'peloponnesian',
        title: 'Peloponnesian War',
        date: '431-404 BCE',
        year: -431,
        description: 'Devastating war between Athens and Sparta weakens Greek city-states.',
        category: 'war',
        region: 'Greece',
        importance: 4
      },
      {
        id: 'alexander',
        title: 'Alexander\'s Conquests',
        date: '336-323 BCE',
        year: -336,
        description: 'Alexander the Great creates one of history\'s largest empires.',
        category: 'empire',
        region: 'Macedonia/Asia',
        importance: 5
      },
      {
        id: 'qin-dynasty',
        title: 'Qin Dynasty Unifies China',
        date: '221 BCE',
        year: -221,
        description: 'Emperor Qin Shi Huang unifies China and begins the Great Wall.',
        category: 'empire',
        region: 'China',
        importance: 5
      },
      {
        id: 'punic-wars',
        title: 'Punic Wars',
        date: '264-146 BCE',
        year: -264,
        description: 'Series of wars between Rome and Carthage, establishing Roman dominance.',
        category: 'war',
        region: 'Mediterranean',
        importance: 4
      },
      {
        id: 'hannibal',
        title: 'Hannibal Crosses the Alps',
        date: '218 BCE',
        year: -218,
        description: 'Carthaginian general Hannibal leads elephants across the Alps to attack Rome.',
        category: 'war',
        region: 'Alps',
        importance: 4
      },
      {
        id: 'julius-caesar',
        title: 'Julius Caesar Assassinated',
        date: '44 BCE',
        year: -44,
        description: 'Roman dictator Julius Caesar is assassinated, ending the Roman Republic.',
        category: 'empire',
        region: 'Rome',
        importance: 5
      },
      {
        id: 'augustus',
        title: 'Roman Empire Begins',
        date: '27 BCE',
        year: -27,
        description: 'Augustus becomes the first Roman Emperor, beginning the Roman Empire.',
        category: 'empire',
        region: 'Rome',
        importance: 5
      },
      {
        id: 'jesus',
        title: 'Birth of Jesus Christ',
        date: '4 BCE',
        year: -4,
        description: 'Jesus of Nazareth is born, founding figure of Christianity.',
        category: 'culture',
        region: 'Palestine',
        importance: 5
      },
      {
        id: 'crucifixion',
        title: 'Crucifixion of Jesus',
        date: '30 CE',
        year: 30,
        description: 'Jesus Christ is crucified, central event in Christian faith.',
        category: 'culture',
        region: 'Jerusalem',
        importance: 5
      },
      {
        id: 'paul',
        title: 'Paul\'s Missionary Journeys',
        date: '45-58 CE',
        year: 45,
        description: 'Apostle Paul spreads Christianity throughout the Roman Empire.',
        category: 'culture',
        region: 'Mediterranean',
        importance: 4
      },
      {
        id: 'pompeii',
        title: 'Destruction of Pompeii',
        date: '79 CE',
        year: 79,
        description: 'Mount Vesuvius erupts, burying Pompeii and preserving it for posterity.',
        category: 'science',
        region: 'Italy',
        importance: 3
      },
      {
        id: 'colosseum',
        title: 'Colosseum Completed',
        date: '80 CE',
        year: 80,
        description: 'The Colosseum in Rome is completed, becoming an iconic symbol of Roman engineering.',
        category: 'empire',
        region: 'Rome',
        importance: 3
      },
      {
        id: 'trajan',
        title: 'Roman Empire at Greatest Extent',
        date: '117 CE',
        year: 117,
        description: 'Under Emperor Trajan, the Roman Empire reaches its maximum territorial extent.',
        category: 'empire',
        region: 'Roman Empire',
        importance: 4
      },
      {
        id: 'constantine',
        title: 'Constantine Converts to Christianity',
        date: '312 CE',
        year: 312,
        description: 'Emperor Constantine converts to Christianity, transforming the Roman Empire.',
        category: 'culture',
        region: 'Rome',
        importance: 5
      },
      {
        id: 'council-nicaea',
        title: 'Council of Nicaea',
        date: '325 CE',
        year: 325,
        description: 'First ecumenical council establishes fundamental Christian doctrines.',
        category: 'culture',
        region: 'Nicaea',
        importance: 4
      },
      {
        id: 'constantinople',
        title: 'Constantinople Founded',
        date: '330 CE',
        year: 330,
        description: 'Constantine establishes Constantinople as the new capital of the Roman Empire.',
        category: 'empire',
        region: 'Byzantine',
        importance: 4
      },
      {
        id: 'huns',
        title: 'Attila the Hun',
        date: '440-453 CE',
        year: 440,
        description: 'Attila leads the Huns in devastating raids across Europe.',
        category: 'war',
        region: 'Europe',
        importance: 3
      },
      {
        id: 'rome-falls',
        title: 'Fall of Western Rome',
        date: '476 CE',
        year: 476,
        description: 'The last Western Roman Emperor is deposed, ending the Western Roman Empire.',
        category: 'empire',
        region: 'Rome',
        importance: 5
      }
    ]
  },
  {
    id: 'medieval',
    name: 'Medieval Era',
    startYear: 500,
    endYear: 1500,
    color: '#7C2D12',
    events: [
      {
        id: 'justinian',
        title: 'Justinian\'s Reconquest',
        date: '527-565 CE',
        year: 527,
        description: 'Byzantine Emperor Justinian attempts to reconquer the Western Roman Empire.',
        category: 'empire',
        region: 'Byzantine',
        importance: 4
      },
      {
        id: 'muhammad',
        title: 'Birth of Muhammad',
        date: '570 CE',
        year: 570,
        description: 'Prophet Muhammad is born, founder of Islam.',
        category: 'culture',
        region: 'Arabia',
        importance: 5
      },
      {
        id: 'hegira',
        title: 'The Hegira',
        date: '622 CE',
        year: 622,
        description: 'Muhammad\'s migration to Medina marks the beginning of the Islamic calendar.',
        category: 'culture',
        region: 'Arabia',
        importance: 4
      },
      {
        id: 'islamic-expansion',
        title: 'Islamic Conquests',
        date: '632-750 CE',
        year: 632,
        description: 'Rapid expansion of Islam across Middle East, North Africa, and Spain.',
        category: 'empire',
        region: 'Middle East',
        importance: 5
      },
      {
        id: 'tang-dynasty',
        title: 'Tang Dynasty Golden Age',
        date: '618-907 CE',
        year: 618,
        description: 'China\'s Tang Dynasty represents a golden age of culture and prosperity.',
        category: 'empire',
        region: 'China',
        importance: 4
      },
      {
        id: 'charlemagne',
        title: 'Charlemagne Crowned Emperor',
        date: '800 CE',
        year: 800,
        description: 'Charlemagne is crowned Holy Roman Emperor, reviving the Western Empire.',
        category: 'empire',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'vikings',
        title: 'Viking Age Begins',
        date: '793 CE',
        year: 793,
        description: 'Vikings raid Lindisfarne monastery, beginning the Viking Age.',
        category: 'war',
        region: 'Scandinavia',
        importance: 3
      },
      {
        id: 'baghdad',
        title: 'House of Wisdom',
        date: '830 CE',
        year: 830,
        description: 'The House of Wisdom in Baghdad becomes a center of learning and translation.',
        category: 'science',
        region: 'Baghdad',
        importance: 4
      },
      {
        id: 'great-schism',
        title: 'Great Schism',
        date: '1054 CE',
        year: 1054,
        description: 'Christianity splits into Eastern Orthodox and Roman Catholic churches.',
        category: 'culture',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'norman-conquest',
        title: 'Norman Conquest',
        date: '1066 CE',
        year: 1066,
        description: 'William the Conqueror defeats Harold II at the Battle of Hastings.',
        category: 'war',
        region: 'England',
        importance: 4
      },
      {
        id: 'first-crusade',
        title: 'First Crusade',
        date: '1095-1099 CE',
        year: 1095,
        description: 'Christian armies capture Jerusalem in the First Crusade.',
        category: 'war',
        region: 'Holy Land',
        importance: 4
      },
      {
        id: 'saladin',
        title: 'Saladin Recaptures Jerusalem',
        date: '1187 CE',
        year: 1187,
        description: 'Muslim leader Saladin recaptures Jerusalem from the Crusaders.',
        category: 'war',
        region: 'Jerusalem',
        importance: 4
      },
      {
        id: 'magna-carta',
        title: 'Magna Carta',
        date: '1215 CE',
        year: 1215,
        description: 'English barons force King John to sign the Magna Carta, limiting royal power.',
        category: 'empire',
        region: 'England',
        importance: 5
      },
      {
        id: 'mongol-empire',
        title: 'Mongol Empire',
        date: '1206-1368 CE',
        year: 1206,
        description: 'Genghis Khan establishes the largest contiguous empire in history.',
        category: 'empire',
        region: 'Asia',
        importance: 5
      },
      {
        id: 'black-death',
        title: 'Black Death',
        date: '1347-1351 CE',
        year: 1347,
        description: 'Bubonic plague kills one-third of Europe\'s population.',
        category: 'science',
        region: 'Europe',
        importance: 5
      },
      {
        id: 'hundred-years-war',
        title: 'Hundred Years\' War',
        date: '1337-1453 CE',
        year: 1337,
        description: 'Long conflict between England and France over the French throne.',
        category: 'war',
        region: 'France/England',
        importance: 4
      },
      {
        id: 'joan-of-arc',
        title: 'Joan of Arc',
        date: '1429 CE',
        year: 1429,
        description: 'Joan of Arc leads French forces to victory at Orléans.',
        category: 'war',
        region: 'France',
        importance: 3
      },
      {
        id: 'constantinople-falls',
        title: 'Fall of Constantinople',
        date: '1453 CE',
        year: 1453,
        description: 'Ottoman Turks capture Constantinople, ending the Byzantine Empire.',
        category: 'empire',
        region: 'Constantinople',
        importance: 5
      },
      {
        id: 'printing-press',
        title: 'Gutenberg\'s Printing Press',
        date: '1440 CE',
        year: 1440,
        description: 'Johannes Gutenberg invents the printing press, revolutionizing communication.',
        category: 'invention',
        region: 'Germany',
        importance: 5
      }
    ]
  },
  {
    id: 'renaissance',
    name: 'Renaissance',
    startYear: 1400,
    endYear: 1650,
    color: '#8B5CF6',
    events: [
      {
        id: 'renaissance-begins',
        title: 'Italian Renaissance',
        date: '1400-1600 CE',
        year: 1400,
        description: 'Cultural rebirth begins in Italy, emphasizing art, science, and humanism.',
        category: 'culture',
        region: 'Italy',
        importance: 5
      },
      {
        id: 'columbus',
        title: 'Columbus Reaches America',
        date: '1492 CE',
        year: 1492,
        description: 'Christopher Columbus reaches the Americas, beginning European colonization.',
        category: 'empire',
        region: 'Americas',
        importance: 5
      },
      {
        id: 'vasco-da-gama',
        title: 'Vasco da Gama Reaches India',
        date: '1498 CE',
        year: 1498,
        description: 'Portuguese explorer reaches India by sea, opening new trade routes.',
        category: 'empire',
        region: 'India',
        importance: 4
      },
      {
        id: 'mona-lisa',
        title: 'Mona Lisa Painted',
        date: '1503-1519 CE',
        year: 1503,
        description: 'Leonardo da Vinci paints the Mona Lisa, masterpiece of Renaissance art.',
        category: 'culture',
        region: 'Italy',
        importance: 3
      },
      {
        id: 'sistine-chapel',
        title: 'Sistine Chapel Ceiling',
        date: '1508-1512 CE',
        year: 1508,
        description: 'Michelangelo paints the ceiling of the Sistine Chapel.',
        category: 'culture',
        region: 'Vatican',
        importance: 4
      },
      {
        id: 'reformation',
        title: 'Protestant Reformation',
        date: '1517 CE',
        year: 1517,
        description: 'Martin Luther posts his 95 Theses, beginning the Protestant Reformation.',
        category: 'culture',
        region: 'Germany',
        importance: 5
      },
      {
        id: 'cortez',
        title: 'Conquest of Aztec Empire',
        date: '1519-1521 CE',
        year: 1519,
        description: 'Hernán Cortés conquers the Aztec Empire in Mexico.',
        category: 'empire',
        region: 'Mexico',
        importance: 4
      },
      {
        id: 'magellan',
        title: 'First Circumnavigation',
        date: '1519-1522 CE',
        year: 1519,
        description: 'Magellan\'s expedition completes the first circumnavigation of the globe.',
        category: 'empire',
        region: 'Global',
        importance: 4
      },
      {
        id: 'pizarro',
        title: 'Conquest of Inca Empire',
        date: '1532 CE',
        year: 1532,
        description: 'Francisco Pizarro conquers the Inca Empire in Peru.',
        category: 'empire',
        region: 'Peru',
        importance: 4
      },
      {
        id: 'copernicus',
        title: 'Heliocentric Theory',
        date: '1543 CE',
        year: 1543,
        description: 'Copernicus publishes his heliocentric theory of the solar system.',
        category: 'science',
        region: 'Poland',
        importance: 5
      },
      {
        id: 'council-trent',
        title: 'Council of Trent',
        date: '1545-1563 CE',
        year: 1545,
        description: 'Catholic Church responds to Protestant Reformation with Counter-Reformation.',
        category: 'culture',
        region: 'Italy',
        importance: 4
      }
    ]
  },
  {
    id: 'early-modern',
    name: 'Early Modern',
    startYear: 1500,
    endYear: 1800,
    color: '#059669',
    events: [
      {
        id: 'spanish-armada',
        title: 'Spanish Armada Defeated',
        date: '1588 CE',
        year: 1588,
        description: 'English fleet defeats the Spanish Armada, establishing English naval power.',
        category: 'war',
        region: 'England',
        importance: 4
      },
      {
        id: 'shakespeare',
        title: 'Shakespeare\'s Hamlet',
        date: '1600 CE',
        year: 1600,
        description: 'William Shakespeare writes Hamlet, pinnacle of English literature.',
        category: 'culture',
        region: 'England',
        importance: 3
      },
      {
        id: 'jamestown',
        title: 'Jamestown Founded',
        date: '1607 CE',
        year: 1607,
        description: 'First permanent English settlement in North America is established.',
        category: 'empire',
        region: 'Virginia',
        importance: 4
      },
      {
        id: 'galileo',
        title: 'Galileo\'s Telescope',
        date: '1609 CE',
        year: 1609,
        description: 'Galileo improves the telescope and makes astronomical discoveries.',
        category: 'science',
        region: 'Italy',
        importance: 4
      },
      {
        id: 'mayflower',
        title: 'Mayflower Compact',
        date: '1620 CE',
        year: 1620,
        description: 'Pilgrims sign the Mayflower Compact, early form of self-government.',
        category: 'empire',
        region: 'Massachusetts',
        importance: 3
      },
      {
        id: 'thirty-years-war',
        title: 'Thirty Years\' War',
        date: '1618-1648 CE',
        year: 1618,
        description: 'Devastating European war over religion and territory.',
        category: 'war',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'english-civil-war',
        title: 'English Civil War',
        date: '1642-1651 CE',
        year: 1642,
        description: 'Civil war in England leads to execution of King Charles I.',
        category: 'war',
        region: 'England',
        importance: 4
      },
      {
        id: 'westphalia',
        title: 'Peace of Westphalia',
        date: '1648 CE',
        year: 1648,
        description: 'Treaty ends Thirty Years\' War and establishes modern state system.',
        category: 'empire',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'great-fire-london',
        title: 'Great Fire of London',
        date: '1666 CE',
        year: 1666,
        description: 'Massive fire destroys medieval London, leading to modern city planning.',
        category: 'science',
        region: 'London',
        importance: 3
      },
      {
        id: 'newton',
        title: 'Newton\'s Principia',
        date: '1687 CE',
        year: 1687,
        description: 'Isaac Newton publishes Principia, laying foundation of classical physics.',
        category: 'science',
        region: 'England',
        importance: 5
      },
      {
        id: 'glorious-revolution',
        title: 'Glorious Revolution',
        date: '1688 CE',
        year: 1688,
        description: 'Bloodless revolution in England establishes constitutional monarchy.',
        category: 'empire',
        region: 'England',
        importance: 4
      },
      {
        id: 'salem-witch-trials',
        title: 'Salem Witch Trials',
        date: '1692 CE',
        year: 1692,
        description: 'Mass hysteria leads to witch trials in Salem, Massachusetts.',
        category: 'culture',
        region: 'Massachusetts',
        importance: 2
      },
      {
        id: 'great-northern-war',
        title: 'Great Northern War',
        date: '1700-1721 CE',
        year: 1700,
        description: 'War establishes Russia as a major European power under Peter the Great.',
        category: 'war',
        region: 'Northern Europe',
        importance: 4
      },
      {
        id: 'war-spanish-succession',
        title: 'War of Spanish Succession',
        date: '1701-1714 CE',
        year: 1701,
        description: 'European war over Spanish throne reshapes balance of power.',
        category: 'war',
        region: 'Europe',
        importance: 3
      },
      {
        id: 'steam-engine',
        title: 'Steam Engine Improved',
        date: '1712 CE',
        year: 1712,
        description: 'Thomas Newcomen improves the steam engine, beginning Industrial Revolution.',
        category: 'invention',
        region: 'England',
        importance: 5
      },
      {
        id: 'seven-years-war',
        title: 'Seven Years\' War',
        date: '1756-1763 CE',
        year: 1756,
        description: 'Global conflict establishes British dominance over France.',
        category: 'war',
        region: 'Global',
        importance: 4
      },
      {
        id: 'boston-tea-party',
        title: 'Boston Tea Party',
        date: '1773 CE',
        year: 1773,
        description: 'American colonists dump tea into Boston Harbor to protest British taxes.',
        category: 'war',
        region: 'Boston',
        importance: 3
      },
      {
        id: 'american-revolution',
        title: 'American Revolution',
        date: '1775-1783 CE',
        year: 1775,
        description: 'American colonies fight for independence from Britain.',
        category: 'war',
        region: 'North America',
        importance: 5
      },
      {
        id: 'declaration-independence',
        title: 'Declaration of Independence',
        date: '1776 CE',
        year: 1776,
        description: 'American colonies declare independence from Britain.',
        category: 'empire',
        region: 'Philadelphia',
        importance: 5
      },
      {
        id: 'wealth-of-nations',
        title: 'Wealth of Nations',
        date: '1776 CE',
        year: 1776,
        description: 'Adam Smith publishes foundational work of modern economics.',
        category: 'science',
        region: 'Scotland',
        importance: 4
      },
      {
        id: 'constitution',
        title: 'US Constitution',
        date: '1787 CE',
        year: 1787,
        description: 'United States Constitution is written, establishing federal government.',
        category: 'empire',
        region: 'Philadelphia',
        importance: 5
      },
      {
        id: 'french-revolution',
        title: 'French Revolution',
        date: '1789 CE',
        year: 1789,
        description: 'French Revolution begins, overthrowing the monarchy and aristocracy.',
        category: 'empire',
        region: 'France',
        importance: 5
      }
    ]
  },
  {
    id: 'modern',
    name: 'Modern Era',
    startYear: 1800,
    endYear: 2000,
    color: '#1E3A8A',
    events: [
      {
        id: 'napoleon',
        title: 'Napoleon\'s Rise',
        date: '1799 CE',
        year: 1799,
        description: 'Napoleon Bonaparte seizes power in France, beginning his empire.',
        category: 'empire',
        region: 'France',
        importance: 5
      },
      {
        id: 'louisiana-purchase',
        title: 'Louisiana Purchase',
        date: '1803 CE',
        year: 1803,
        description: 'United States doubles in size with purchase of Louisiana Territory.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'trafalgar',
        title: 'Battle of Trafalgar',
        date: '1805 CE',
        year: 1805,
        description: 'British naval victory establishes British control of the seas.',
        category: 'war',
        region: 'Atlantic',
        importance: 4
      },
      {
        id: 'waterloo',
        title: 'Battle of Waterloo',
        date: '1815 CE',
        year: 1815,
        description: 'Napoleon is defeated at Waterloo, ending his empire.',
        category: 'war',
        region: 'Belgium',
        importance: 5
      },
      {
        id: 'independence-latin-america',
        title: 'Latin American Independence',
        date: '1810-1825 CE',
        year: 1810,
        description: 'Latin American countries gain independence from Spain and Portugal.',
        category: 'empire',
        region: 'Latin America',
        importance: 4
      },
      {
        id: 'war-1812',
        title: 'War of 1812',
        date: '1812-1815 CE',
        year: 1812,
        description: 'Second war between United States and Britain.',
        category: 'war',
        region: 'North America',
        importance: 3
      },
      {
        id: 'steam-locomotive',
        title: 'First Steam Locomotive',
        date: '1825 CE',
        year: 1825,
        description: 'First passenger railway opens, revolutionizing transportation.',
        category: 'invention',
        region: 'England',
        importance: 4
      },
      {
        id: 'photography',
        title: 'Photography Invented',
        date: '1839 CE',
        year: 1839,
        description: 'Louis Daguerre perfects photography, changing how we record history.',
        category: 'invention',
        region: 'France',
        importance: 4
      },
      {
        id: 'opium-wars',
        title: 'Opium Wars',
        date: '1839-1860 CE',
        year: 1839,
        description: 'Britain forces China to open to foreign trade and influence.',
        category: 'war',
        region: 'China',
        importance: 4
      },
      {
        id: 'telegraph',
        title: 'Telegraph Invented',
        date: '1844 CE',
        year: 1844,
        description: 'Samuel Morse sends first telegraph message, revolutionizing communication.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'irish-potato-famine',
        title: 'Irish Potato Famine',
        date: '1845-1852 CE',
        year: 1845,
        description: 'Potato blight causes mass starvation and emigration from Ireland.',
        category: 'science',
        region: 'Ireland',
        importance: 3
      },
      {
        id: 'revolutions-1848',
        title: 'Revolutions of 1848',
        date: '1848 CE',
        year: 1848,
        description: 'Democratic revolutions sweep across Europe.',
        category: 'empire',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'california-gold-rush',
        title: 'California Gold Rush',
        date: '1849 CE',
        year: 1849,
        description: 'Discovery of gold in California triggers massive migration west.',
        category: 'empire',
        region: 'California',
        importance: 3
      },
      {
        id: 'crimean-war',
        title: 'Crimean War',
        date: '1853-1856 CE',
        year: 1853,
        description: 'First modern war with extensive use of photography and nursing.',
        category: 'war',
        region: 'Crimea',
        importance: 3
      },
      {
        id: 'origin-species',
        title: 'Origin of Species',
        date: '1859 CE',
        year: 1859,
        description: 'Charles Darwin publishes theory of evolution by natural selection.',
        category: 'science',
        region: 'England',
        importance: 5
      },
      {
        id: 'american-civil-war',
        title: 'American Civil War',
        date: '1861-1865 CE',
        year: 1861,
        description: 'Civil war in America over slavery and states\' rights.',
        category: 'war',
        region: 'United States',
        importance: 5
      },
      {
        id: 'emancipation-proclamation',
        title: 'Emancipation Proclamation',
        date: '1863 CE',
        year: 1863,
        description: 'Abraham Lincoln declares freedom for slaves in rebellious states.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'lincoln-assassination',
        title: 'Lincoln Assassination',
        date: '1865 CE',
        year: 1865,
        description: 'President Abraham Lincoln is assassinated by John Wilkes Booth.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'transcontinental-railroad',
        title: 'Transcontinental Railroad',
        date: '1869 CE',
        year: 1869,
        description: 'First transcontinental railroad completed in United States.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'suez-canal',
        title: 'Suez Canal Opens',
        date: '1869 CE',
        year: 1869,
        description: 'Suez Canal opens, connecting Mediterranean and Red Seas.',
        category: 'invention',
        region: 'Egypt',
        importance: 4
      },
      {
        id: 'franco-prussian-war',
        title: 'Franco-Prussian War',
        date: '1870-1871 CE',
        year: 1870,
        description: 'Prussian victory leads to German unification and French defeat.',
        category: 'war',
        region: 'Europe',
        importance: 4
      },
      {
        id: 'german-unification',
        title: 'German Unification',
        date: '1871 CE',
        year: 1871,
        description: 'German states unite under Prussian leadership to form German Empire.',
        category: 'empire',
        region: 'Germany',
        importance: 4
      },
      {
        id: 'telephone',
        title: 'Telephone Invented',
        date: '1876 CE',
        year: 1876,
        description: 'Alexander Graham Bell invents the telephone.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'light-bulb',
        title: 'Light Bulb Invented',
        date: '1879 CE',
        year: 1879,
        description: 'Thomas Edison perfects the incandescent light bulb.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'scramble-africa',
        title: 'Scramble for Africa',
        date: '1880-1914 CE',
        year: 1880,
        description: 'European powers colonize most of Africa.',
        category: 'empire',
        region: 'Africa',
        importance: 4
      },
      {
        id: 'automobile',
        title: 'First Automobile',
        date: '1885 CE',
        year: 1885,
        description: 'Karl Benz builds the first practical automobile.',
        category: 'invention',
        region: 'Germany',
        importance: 4
      },
      {
        id: 'statue-liberty',
        title: 'Statue of Liberty',
        date: '1886 CE',
        year: 1886,
        description: 'Statue of Liberty is dedicated in New York Harbor.',
        category: 'culture',
        region: 'United States',
        importance: 2
      },
      {
        id: 'eiffel-tower',
        title: 'Eiffel Tower Built',
        date: '1889 CE',
        year: 1889,
        description: 'Eiffel Tower is completed for the Paris Exposition.',
        category: 'culture',
        region: 'France',
        importance: 2
      },
      {
        id: 'wounded-knee',
        title: 'Wounded Knee Massacre',
        date: '1890 CE',
        year: 1890,
        description: 'US Army kills hundreds of Lakota at Wounded Knee, ending Indian Wars.',
        category: 'war',
        region: 'United States',
        importance: 3
      },
      {
        id: 'x-rays',
        title: 'X-rays Discovered',
        date: '1895 CE',
        year: 1895,
        description: 'Wilhelm Röntgen discovers X-rays, revolutionizing medicine.',
        category: 'science',
        region: 'Germany',
        importance: 4
      },
      {
        id: 'spanish-american-war',
        title: 'Spanish-American War',
        date: '1898 CE',
        year: 1898,
        description: 'United States defeats Spain, becoming a world power.',
        category: 'war',
        region: 'Caribbean/Pacific',
        importance: 4
      },
      {
        id: 'boer-war',
        title: 'Boer War',
        date: '1899-1902 CE',
        year: 1899,
        description: 'Britain defeats Boer republics in South Africa.',
        category: 'war',
        region: 'South Africa',
        importance: 3
      },
      {
        id: 'wright-brothers',
        title: 'First Flight',
        date: '1903 CE',
        year: 1903,
        description: 'Wright brothers achieve first powered flight at Kitty Hawk.',
        category: 'invention',
        region: 'United States',
        importance: 5
      },
      {
        id: 'einstein-relativity',
        title: 'Theory of Relativity',
        date: '1905 CE',
        year: 1905,
        description: 'Einstein publishes special theory of relativity.',
        category: 'science',
        region: 'Germany',
        importance: 5
      },
      {
        id: 'san-francisco-earthquake',
        title: 'San Francisco Earthquake',
        date: '1906 CE',
        year: 1906,
        description: 'Massive earthquake and fire devastate San Francisco.',
        category: 'science',
        region: 'United States',
        importance: 2
      },
      {
        id: 'model-t',
        title: 'Model T Ford',
        date: '1908 CE',
        year: 1908,
        description: 'Henry Ford introduces the Model T, making cars affordable.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'south-pole',
        title: 'South Pole Reached',
        date: '1911 CE',
        year: 1911,
        description: 'Roald Amundsen becomes first to reach the South Pole.',
        category: 'empire',
        region: 'Antarctica',
        importance: 3
      },
      {
        id: 'titanic',
        title: 'Titanic Sinks',
        date: '1912 CE',
        year: 1912,
        description: 'RMS Titanic sinks on maiden voyage, killing over 1,500 people.',
        category: 'science',
        region: 'Atlantic',
        importance: 3
      },
      {
        id: 'world-war-1',
        title: 'World War I',
        date: '1914-1918 CE',
        year: 1914,
        description: 'First global war kills millions and reshapes world order.',
        category: 'war',
        region: 'Global',
        importance: 5
      },
      {
        id: 'russian-revolution',
        title: 'Russian Revolution',
        date: '1917 CE',
        year: 1917,
        description: 'Bolsheviks overthrow Russian government, establishing Soviet Union.',
        category: 'empire',
        region: 'Russia',
        importance: 5
      },
      {
        id: 'spanish-flu',
        title: 'Spanish Flu Pandemic',
        date: '1918-1919 CE',
        year: 1918,
        description: 'Influenza pandemic kills 50-100 million people worldwide.',
        category: 'science',
        region: 'Global',
        importance: 4
      },
      {
        id: 'womens-suffrage',
        title: 'Women\'s Suffrage',
        date: '1920 CE',
        year: 1920,
        description: '19th Amendment grants women the right to vote in United States.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'radio',
        title: 'Radio Broadcasting',
        date: '1920 CE',
        year: 1920,
        description: 'First commercial radio broadcasts begin, transforming communication.',
        category: 'invention',
        region: 'United States',
        importance: 3
      },
      {
        id: 'insulin',
        title: 'Insulin Discovered',
        date: '1922 CE',
        year: 1922,
        description: 'Discovery of insulin saves millions of diabetics.',
        category: 'science',
        region: 'Canada',
        importance: 4
      },
      {
        id: 'television',
        title: 'Television Invented',
        date: '1926 CE',
        year: 1926,
        description: 'John Logie Baird demonstrates first television broadcast.',
        category: 'invention',
        region: 'Scotland',
        importance: 4
      },
      {
        id: 'penicillin',
        title: 'Penicillin Discovered',
        date: '1928 CE',
        year: 1928,
        description: 'Alexander Fleming discovers penicillin, first antibiotic.',
        category: 'science',
        region: 'Scotland',
        importance: 5
      },
      {
        id: 'stock-market-crash',
        title: 'Stock Market Crash',
        date: '1929 CE',
        year: 1929,
        description: 'Wall Street crash triggers the Great Depression.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'great-depression',
        title: 'Great Depression',
        date: '1929-1939 CE',
        year: 1929,
        description: 'Worldwide economic depression affects millions.',
        category: 'empire',
        region: 'Global',
        importance: 4
      },
      {
        id: 'hitler-rises',
        title: 'Hitler Rises to Power',
        date: '1933 CE',
        year: 1933,
        description: 'Adolf Hitler becomes Chancellor of Germany.',
        category: 'empire',
        region: 'Germany',
        importance: 5
      },
      {
        id: 'new-deal',
        title: 'New Deal',
        date: '1933-1939 CE',
        year: 1933,
        description: 'FDR\'s New Deal programs combat the Great Depression.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'world-war-2',
        title: 'World War II',
        date: '1939-1945 CE',
        year: 1939,
        description: 'Second global war becomes deadliest conflict in human history.',
        category: 'war',
        region: 'Global',
        importance: 5
      },
      {
        id: 'pearl-harbor',
        title: 'Pearl Harbor Attack',
        date: '1941 CE',
        year: 1941,
        description: 'Japan attacks Pearl Harbor, bringing US into World War II.',
        category: 'war',
        region: 'Hawaii',
        importance: 5
      },
      {
        id: 'holocaust',
        title: 'The Holocaust',
        date: '1941-1945 CE',
        year: 1941,
        description: 'Nazi Germany systematically murders 6 million Jews.',
        category: 'war',
        region: 'Europe',
        importance: 5
      },
      {
        id: 'd-day',
        title: 'D-Day Invasion',
        date: '1944 CE',
        year: 1944,
        description: 'Allied forces invade Normandy, opening second front in Europe.',
        category: 'war',
        region: 'France',
        importance: 5
      },
      {
        id: 'atomic-bomb',
        title: 'Atomic Bombs Dropped',
        date: '1945 CE',
        year: 1945,
        description: 'US drops atomic bombs on Hiroshima and Nagasaki.',
        category: 'war',
        region: 'Japan',
        importance: 5
      },
      {
        id: 'united-nations',
        title: 'United Nations Founded',
        date: '1945 CE',
        year: 1945,
        description: 'United Nations is established to promote world peace.',
        category: 'empire',
        region: 'Global',
        importance: 4
      },
      {
        id: 'cold-war',
        title: 'Cold War Begins',
        date: '1947 CE',
        year: 1947,
        description: 'Ideological conflict between US and Soviet Union begins.',
        category: 'war',
        region: 'Global',
        importance: 5
      },
      {
        id: 'israel-independence',
        title: 'Israel Independence',
        date: '1948 CE',
        year: 1948,
        description: 'State of Israel is established, leading to Arab-Israeli conflict.',
        category: 'empire',
        region: 'Middle East',
        importance: 4
      },
      {
        id: 'nato',
        title: 'NATO Founded',
        date: '1949 CE',
        year: 1949,
        description: 'North Atlantic Treaty Organization formed for collective defense.',
        category: 'empire',
        region: 'North Atlantic',
        importance: 4
      },
      {
        id: 'communist-china',
        title: 'Communist China',
        date: '1949 CE',
        year: 1949,
        description: 'Mao Zedong establishes People\'s Republic of China.',
        category: 'empire',
        region: 'China',
        importance: 5
      },
      {
        id: 'korean-war',
        title: 'Korean War',
        date: '1950-1953 CE',
        year: 1950,
        description: 'First major conflict of the Cold War divides Korea.',
        category: 'war',
        region: 'Korea',
        importance: 4
      },
      {
        id: 'dna-structure',
        title: 'DNA Structure Discovered',
        date: '1953 CE',
        year: 1953,
        description: 'Watson and Crick discover the double helix structure of DNA.',
        category: 'science',
        region: 'England',
        importance: 5
      },
      {
        id: 'brown-v-board',
        title: 'Brown v. Board',
        date: '1954 CE',
        year: 1954,
        description: 'Supreme Court declares school segregation unconstitutional.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'sputnik',
        title: 'Sputnik Launched',
        date: '1957 CE',
        year: 1957,
        description: 'Soviet Union launches first artificial satellite, beginning Space Race.',
        category: 'science',
        region: 'Soviet Union',
        importance: 4
      },
      {
        id: 'civil-rights-movement',
        title: 'Civil Rights Movement',
        date: '1955-1968 CE',
        year: 1955,
        description: 'African Americans fight for equal rights in the United States.',
        category: 'empire',
        region: 'United States',
        importance: 5
      },
      {
        id: 'berlin-wall',
        title: 'Berlin Wall Built',
        date: '1961 CE',
        year: 1961,
        description: 'East Germany builds wall dividing Berlin, symbol of Cold War.',
        category: 'empire',
        region: 'Germany',
        importance: 4
      },
      {
        id: 'jfk-assassination',
        title: 'JFK Assassination',
        date: '1963 CE',
        year: 1963,
        description: 'President John F. Kennedy is assassinated in Dallas.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'vietnam-war',
        title: 'Vietnam War',
        date: '1955-1975 CE',
        year: 1955,
        description: 'Long, controversial war divides America and ends in defeat.',
        category: 'war',
        region: 'Vietnam',
        importance: 4
      },
      {
        id: 'moon-landing',
        title: 'Moon Landing',
        date: '1969 CE',
        year: 1969,
        description: 'Apollo 11 lands first humans on the moon.',
        category: 'science',
        region: 'Moon',
        importance: 5
      },
      {
        id: 'woodstock',
        title: 'Woodstock Festival',
        date: '1969 CE',
        year: 1969,
        description: 'Iconic music festival symbolizes 1960s counterculture.',
        category: 'culture',
        region: 'United States',
        importance: 2
      },
      {
        id: 'watergate',
        title: 'Watergate Scandal',
        date: '1972-1974 CE',
        year: 1972,
        description: 'Political scandal leads to President Nixon\'s resignation.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'oil-crisis',
        title: 'Oil Crisis',
        date: '1973 CE',
        year: 1973,
        description: 'Arab oil embargo causes global energy crisis.',
        category: 'empire',
        region: 'Global',
        importance: 3
      },
      {
        id: 'personal-computer',
        title: 'Personal Computer',
        date: '1975 CE',
        year: 1975,
        description: 'First personal computers launched, beginning computer revolution.',
        category: 'invention',
        region: 'United States',
        importance: 5
      },
      {
        id: 'chernobyl',
        title: 'Chernobyl Disaster',
        date: '1986 CE',
        year: 1986,
        description: 'Nuclear accident in Ukraine becomes worst nuclear disaster.',
        category: 'science',
        region: 'Ukraine',
        importance: 4
      },
      {
        id: 'berlin-wall-falls',
        title: 'Berlin Wall Falls',
        date: '1989 CE',
        year: 1989,
        description: 'Berlin Wall is torn down, symbolizing end of Cold War.',
        category: 'empire',
        region: 'Germany',
        importance: 5
      },
      {
        id: 'soviet-union-collapses',
        title: 'Soviet Union Collapses',
        date: '1991 CE',
        year: 1991,
        description: 'Soviet Union dissolves, ending the Cold War.',
        category: 'empire',
        region: 'Soviet Union',
        importance: 5
      },
      {
        id: 'world-wide-web',
        title: 'World Wide Web',
        date: '1991 CE',
        year: 1991,
        description: 'Tim Berners-Lee creates the World Wide Web.',
        category: 'invention',
        region: 'Switzerland',
        importance: 5
      },
      {
        id: 'gulf-war',
        title: 'Gulf War',
        date: '1991 CE',
        year: 1991,
        description: 'Coalition forces defeat Iraq in first televised war.',
        category: 'war',
        region: 'Middle East',
        importance: 3
      }
    ]
  },
  {
    id: 'contemporary',
    name: 'Contemporary Era',
    startYear: 2000,
    endYear: 2025,
    color: '#DC2626',
    events: [
      {
        id: '9-11',
        title: 'September 11 Attacks',
        date: '2001 CE',
        year: 2001,
        description: 'Terrorist attacks on World Trade Center and Pentagon change world.',
        category: 'war',
        region: 'United States',
        importance: 5
      },
      {
        id: 'afghanistan-war',
        title: 'War in Afghanistan',
        date: '2001-2021 CE',
        year: 2001,
        description: 'US-led invasion of Afghanistan becomes longest war in US history.',
        category: 'war',
        region: 'Afghanistan',
        importance: 4
      },
      {
        id: 'iraq-war',
        title: 'Iraq War',
        date: '2003-2011 CE',
        year: 2003,
        description: 'US-led invasion topples Saddam Hussein but destabilizes region.',
        category: 'war',
        region: 'Iraq',
        importance: 4
      },
      {
        id: 'facebook',
        title: 'Facebook Founded',
        date: '2004 CE',
        year: 2004,
        description: 'Mark Zuckerberg creates Facebook, revolutionizing social media.',
        category: 'invention',
        region: 'United States',
        importance: 4
      },
      {
        id: 'youtube',
        title: 'YouTube Founded',
        date: '2005 CE',
        year: 2005,
        description: 'Video sharing platform transforms media and entertainment.',
        category: 'invention',
        region: 'United States',
        importance: 3
      },
      {
        id: 'financial-crisis',
        title: 'Global Financial Crisis',
        date: '2008 CE',
        year: 2008,
        description: 'Worst financial crisis since Great Depression affects global economy.',
        category: 'empire',
        region: 'Global',
        importance: 4
      },
      {
        id: 'obama-elected',
        title: 'Obama Elected',
        date: '2008 CE',
        year: 2008,
        description: 'Barack Obama becomes first African American US President.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'arab-spring',
        title: 'Arab Spring',
        date: '2010-2012 CE',
        year: 2010,
        description: 'Democratic uprisings sweep across Middle East and North Africa.',
        category: 'empire',
        region: 'Middle East',
        importance: 4
      },
      {
        id: 'bin-laden-killed',
        title: 'Bin Laden Killed',
        date: '2011 CE',
        year: 2011,
        description: 'US forces kill Osama bin Laden in Pakistan.',
        category: 'war',
        region: 'Pakistan',
        importance: 4
      },
      {
        id: 'syrian-civil-war',
        title: 'Syrian Civil War',
        date: '2011-present',
        year: 2011,
        description: 'Ongoing civil war creates massive refugee crisis.',
        category: 'war',
        region: 'Syria',
        importance: 4
      },
      {
        id: 'brexit',
        title: 'Brexit Vote',
        date: '2016 CE',
        year: 2016,
        description: 'United Kingdom votes to leave the European Union.',
        category: 'empire',
        region: 'United Kingdom',
        importance: 4
      },
      {
        id: 'trump-elected',
        title: 'Trump Elected',
        date: '2016 CE',
        year: 2016,
        description: 'Donald Trump wins surprising victory in US presidential election.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'covid-19',
        title: 'COVID-19 Pandemic',
        date: '2020-2023 CE',
        year: 2020,
        description: 'Global pandemic kills millions and transforms society.',
        category: 'science',
        region: 'Global',
        importance: 5
      },
      {
        id: 'capitol-riot',
        title: 'January 6 Capitol Riot',
        date: '2021 CE',
        year: 2021,
        description: 'Supporters of Donald Trump storm US Capitol building.',
        category: 'empire',
        region: 'United States',
        importance: 4
      },
      {
        id: 'ukraine-war',
        title: 'Russia Invades Ukraine',
        date: '2022 CE',
        year: 2022,
        description: 'Russia launches full-scale invasion of Ukraine.',
        category: 'war',
        region: 'Ukraine',
        importance: 5
      },
      {
        id: 'chatgpt',
        title: 'ChatGPT Released',
        date: '2022 CE',
        year: 2022,
        description: 'OpenAI releases ChatGPT, sparking AI revolution.',
        category: 'invention',
        region: 'United States',
        importance: 4
      }
    ]
  }
];

export const historicalFigures: HistoricalFigure[] = [
  {
    id: 'cleopatra',
    name: 'Cleopatra VII',
    period: '69-30 BCE',
    title: 'Last Pharaoh of Egypt',
    description: 'Cleopatra VII was the last active pharaoh of Ancient Egypt, known for her intelligence, political acumen, and relationships with Julius Caesar and Mark Antony. She spoke nine languages and was highly educated in mathematics, philosophy, and rhetoric.',
    achievements: [
      'Spoke nine languages fluently including Egyptian, Greek, and Latin',
      'Maintained Egypt\'s independence for nearly two decades',
      'Advanced Egypt\'s economy through strategic trade partnerships',
      'Patron of arts, learning, and the Great Library of Alexandria',
      'Successfully negotiated with Rome\'s most powerful leaders'
    ],
    imageUrl: 'https://images.pexels.com/photos/8728380/pexels-photo-8728380.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Young Pharaoh',
        content: 'At age 18, Cleopatra ascended to the throne alongside her younger brother Ptolemy XIII. The young pharaoh faced immediate challenges to her rule from court conspirators and the growing power of Rome. Egypt\'s wealth made it a prize coveted by Roman generals, while internal strife threatened the kingdom\'s stability.',
        year: -51,
        choices: [
          { id: 'ch1a', text: 'Seek alliance with Julius Caesar', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Focus on strengthening Egypt internally', nextChapter: 'ch2b' }
        ]
      },
      {
        id: 'ch2a',
        title: 'The Roman Alliance',
        content: 'Cleopatra\'s decision to ally with Julius Caesar proved pivotal. When Caesar arrived in Alexandria pursuing Pompey, she famously had herself smuggled to him in a carpet. Their political and romantic alliance secured Egypt\'s position and gave Caesar access to Egypt\'s vast wealth.',
        year: -48,
        choices: [
          { id: 'ch2a1', text: 'Accompany Caesar to Rome', nextChapter: 'ch3a' },
          { id: 'ch2a2', text: 'Remain in Egypt to consolidate power', nextChapter: 'ch3b' }
        ]
      },
      {
        id: 'ch2b',
        title: 'The Independent Path',
        content: 'Choosing to focus on Egypt\'s internal strength, Cleopatra invested in infrastructure, trade, and cultural projects. She revitalized the Great Library of Alexandria and expanded trade routes to India and Arabia. However, Roman pressure continued to mount.',
        year: -48,
        choices: [
          { id: 'ch2b1', text: 'Eventually seek Roman protection', nextChapter: 'ch3c' },
          { id: 'ch2b2', text: 'Form alliance with other eastern kingdoms', nextChapter: 'ch3d' }
        ]
      }
    ]
  },
  {
    id: 'leonardo',
    name: 'Leonardo da Vinci',
    period: '1452-1519 CE',
    title: 'Renaissance Polymath',
    description: 'Leonardo da Vinci was an Italian polymath whose areas of interest included invention, drawing, painting, sculpture, architecture, science, music, mathematics, engineering, literature, anatomy, geology, astronomy, botany, and cartography. He epitomized the Renaissance humanist ideal.',
    achievements: [
      'Painted the Mona Lisa and The Last Supper, masterpieces of Renaissance art',
      'Designed flying machines, tanks, and submarines centuries before their time',
      'Conducted detailed anatomical studies through dissection',
      'Created architectural designs and engineering blueprints',
      'Advanced understanding of optics, hydraulics, and mechanics'
    ],
    imageUrl: 'https://images.pexels.com/photos/8251515/pexels-photo-8251515.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Apprentice',
        content: 'Young Leonardo begins his apprenticeship in Andrea del Verrocchio\'s workshop in Florence at age 14. His extraordinary talent quickly becomes apparent as he masters painting techniques and shows curiosity about engineering and anatomy. The workshop buzzes with Renaissance innovation.',
        year: 1466,
        choices: [
          { id: 'ch1a', text: 'Focus intensively on perfecting painting techniques', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Divide time between art and engineering studies', nextChapter: 'ch2b' }
        ]
      },
      {
        id: 'ch2a',
        title: 'The Master Painter',
        content: 'Leonardo\'s dedication to painting pays off as he develops revolutionary techniques like sfumato and chiaroscuro. His portraits capture unprecedented psychological depth, and his religious works show divine inspiration. Wealthy patrons compete for his services.',
        year: 1478,
        choices: [
          { id: 'ch2a1', text: 'Accept commission from the Medici family', nextChapter: 'ch3a' },
          { id: 'ch2a2', text: 'Seek patronage from the French court', nextChapter: 'ch3b' }
        ]
      },
      {
        id: 'ch2b',
        title: 'The Universal Genius',
        content: 'Leonardo\'s diverse interests lead him to study anatomy, engineering, and natural philosophy alongside his art. His notebooks fill with designs for flying machines, war engines, and architectural marvels. He becomes known as a true Renaissance man.',
        year: 1478,
        choices: [
          { id: 'ch2b1', text: 'Focus on military engineering for powerful rulers', nextChapter: 'ch3c' },
          { id: 'ch2b2', text: 'Pursue scientific research and anatomical studies', nextChapter: 'ch3d' }
        ]
      }
    ]
  },
  {
    id: 'napoleon',
    name: 'Napoleon Bonaparte',
    period: '1769-1821 CE',
    title: 'Emperor of the French',
    description: 'Napoleon Bonaparte was a French military general and political leader who rose to prominence during the French Revolution. He became Emperor of the French and conquered much of continental Europe before his ultimate defeat and exile.',
    achievements: [
      'Rose from artillery officer to Emperor of France',
      'Created the Napoleonic Code, influencing legal systems worldwide',
      'Won numerous military campaigns across Europe',
      'Established merit-based advancement in government and military',
      'Founded modern educational and administrative systems'
    ],
    imageUrl: 'https://images.pexels.com/photos/8728380/pexels-photo-8728380.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Young Officer',
        content: 'Napoleon, a young artillery officer from Corsica, witnesses the chaos of the French Revolution. His military genius becomes apparent during the siege of Toulon, where his strategic use of cannons helps recapture the city from royalist forces.',
        year: 1793,
        choices: [
          { id: 'ch1a', text: 'Align with the radical Jacobins', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Maintain political neutrality and focus on military merit', nextChapter: 'ch2b' }
        ]
      }
    ]
  },
  {
    id: 'shakespeare',
    name: 'William Shakespeare',
    period: '1564-1616 CE',
    title: 'The Bard of Avon',
    description: 'William Shakespeare was an English playwright, poet, and actor, widely regarded as the greatest writer in the English language and the world\'s greatest dramatist. His works include 39 plays and 154 sonnets.',
    achievements: [
      'Wrote 39 plays including Hamlet, Macbeth, and Romeo and Juliet',
      'Composed 154 sonnets that revolutionized English poetry',
      'Invented over 1,700 words still used in English today',
      'Created complex characters that explore universal human themes',
      'Influenced literature, theater, and language for over 400 years'
    ],
    imageUrl: 'https://images.pexels.com/photos/8251515/pexels-photo-8251515.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Stratford Youth',
        content: 'Young William grows up in Stratford-upon-Avon, son of a glove maker. His education at the local grammar school introduces him to Latin classics and rhetoric. The traveling theater companies that visit Stratford spark his imagination.',
        year: 1580,
        choices: [
          { id: 'ch1a', text: 'Join a traveling theater company', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Continue family business while writing in spare time', nextChapter: 'ch2b' }
        ]
      }
    ]
  },
  {
    id: 'einstein',
    name: 'Albert Einstein',
    period: '1879-1955 CE',
    title: 'Theoretical Physicist',
    description: 'Albert Einstein was a German-born theoretical physicist who developed the theory of relativity, one of the two pillars of modern physics. His work is known for its influence on the philosophy of science.',
    achievements: [
      'Developed the special and general theories of relativity',
      'Won Nobel Prize in Physics for explanation of photoelectric effect',
      'Contributed to quantum theory and statistical mechanics',
      'Famous equation E=mc² revolutionized understanding of energy and matter',
      'Advocated for civil rights and nuclear disarmament'
    ],
    imageUrl: 'https://images.pexels.com/photos/8728380/pexels-photo-8728380.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Patent Clerk',
        content: 'Working as a patent clerk in Bern, Switzerland, Einstein uses his spare time to think about fundamental questions of physics. His "miracle year" of 1905 approaches, when he will publish papers that revolutionize science.',
        year: 1904,
        choices: [
          { id: 'ch1a', text: 'Focus on theoretical problems of space and time', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Investigate the nature of light and energy', nextChapter: 'ch2b' }
        ]
      }
    ]
  },
  {
    id: 'marie-curie',
    name: 'Marie Curie',
    period: '1867-1934 CE',
    title: 'Pioneering Physicist and Chemist',
    description: 'Marie Curie was a Polish-French physicist and chemist who conducted pioneering research on radioactivity. She was the first woman to win a Nobel Prize and the only person to win Nobel Prizes in two different scientific fields.',
    achievements: [
      'First woman to win a Nobel Prize (Physics, 1903)',
      'Only person to win Nobel Prizes in two different sciences (Chemistry, 1911)',
      'Discovered elements polonium and radium',
      'Pioneered research on radioactivity (term she coined)',
      'Founded mobile X-ray units during World War I'
    ],
    imageUrl: 'https://images.pexels.com/photos/8728380/pexels-photo-8728380.jpeg?auto=compress&cs=tinysrgb&w=400',
    story: [
      {
        id: 'ch1',
        title: 'The Determined Student',
        content: 'Maria Sklodowska leaves Poland for Paris to study at the Sorbonne, living in poverty but determined to pursue science. She meets Pierre Curie, and together they begin investigating the mysterious rays emitted by uranium.',
        year: 1894,
        choices: [
          { id: 'ch1a', text: 'Focus on isolating new radioactive elements', nextChapter: 'ch2a' },
          { id: 'ch1b', text: 'Study the medical applications of radioactivity', nextChapter: 'ch2b' }
        ]
      }
    ]
  }
];

export const todaysEvents: HistoricalEvent[] = [
  {
    id: 'today1',
    title: 'The Boston Tea Party',
    date: 'December 16, 1773',
    year: 1773,
    description: 'American colonists, disguised as Native Americans, dumped 342 chests of British East India Company tea into Boston Harbor to protest the Tea Act, which gave the company a monopoly on tea sales in the American colonies while maintaining a tax on tea.',
    category: 'war',
    region: 'North America',
    importance: 4
  },
  {
    id: 'today2',
    title: 'Wright Brothers First Flight',
    date: 'December 17, 1903',
    year: 1903,
    description: 'Orville and Wilbur Wright achieved the first powered, sustained, and controlled heavier-than-air human flight at Kitty Hawk, North Carolina. The flight lasted 12 seconds and covered 120 feet.',
    category: 'invention',
    region: 'United States',
    importance: 5
  },
  {
    id: 'today3',
    title: 'Beethoven\'s Birth',
    date: 'December 17, 1770',
    year: 1770,
    description: 'Ludwig van Beethoven, one of the greatest composers in history, was born in Bonn, Germany. Despite losing his hearing, he composed nine symphonies and numerous other masterpieces.',
    category: 'culture',
    region: 'Germany',
    importance: 4
  }
];

export const quizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'Which pharaoh was the Great Pyramid of Giza built for?',
    options: ['Khufu (Cheops)', 'Khafre', 'Menkaure', 'Tutankhamun'],
    correctAnswer: 0,
    explanation: 'The Great Pyramid was built as a tomb for Pharaoh Khufu (also known as Cheops) around 2580 BCE. It\'s the oldest and largest of the three pyramids at Giza.',
    difficulty: 'easy'
  },
  {
    id: 'q2',
    question: 'In what year did the Norman Conquest of England take place?',
    options: ['1066', '1067', '1065', '1068'],
    correctAnswer: 0,
    explanation: 'The Norman Conquest occurred in 1066 when William the Conqueror defeated Harold II at the Battle of Hastings, fundamentally changing English culture and language.',
    difficulty: 'medium'
  },
  {
    id: 'q3',
    question: 'Who wrote the "Origin of Species"?',
    options: ['Charles Darwin', 'Alfred Wallace', 'Gregor Mendel', 'Louis Pasteur'],
    correctAnswer: 0,
    explanation: 'Charles Darwin published "On the Origin of Species" in 1859, introducing the theory of evolution by natural selection.',
    difficulty: 'easy'
  },
  {
    id: 'q4',
    question: 'Which empire was ruled by Genghis Khan?',
    options: ['Ottoman Empire', 'Mongol Empire', 'Byzantine Empire', 'Persian Empire'],
    correctAnswer: 1,
    explanation: 'Genghis Khan founded and ruled the Mongol Empire, which became the largest contiguous land empire in history.',
    difficulty: 'easy'
  },
  {
    id: 'q5',
    question: 'The Renaissance began in which country?',
    options: ['France', 'Germany', 'Italy', 'Spain'],
    correctAnswer: 2,
    explanation: 'The Renaissance began in Italy during the 14th century, starting in cities like Florence and Venice before spreading across Europe.',
    difficulty: 'easy'
  },
  {
    id: 'q6',
    question: 'What year did World War II end?',
    options: ['1944', '1945', '1946', '1947'],
    correctAnswer: 1,
    explanation: 'World War II ended in 1945, with Germany surrendering in May and Japan surrendering in September after the atomic bombs.',
    difficulty: 'easy'
  },
  {
    id: 'q7',
    question: 'Who was the first person to walk on the moon?',
    options: ['Buzz Aldrin', 'Neil Armstrong', 'John Glenn', 'Alan Shepard'],
    correctAnswer: 1,
    explanation: 'Neil Armstrong was the first person to walk on the moon on July 20, 1969, during the Apollo 11 mission.',
    difficulty: 'easy'
  },
  {
    id: 'q8',
    question: 'The Black Death occurred during which century?',
    options: ['13th century', '14th century', '15th century', '16th century'],
    correctAnswer: 1,
    explanation: 'The Black Death, a devastating plague pandemic, occurred in the 14th century (1347-1351), killing an estimated one-third of Europe\'s population.',
    difficulty: 'medium'
  },
  {
    id: 'q9',
    question: 'Which ancient wonder of the world was located in Alexandria?',
    options: ['Colossus of Rhodes', 'Lighthouse of Alexandria', 'Hanging Gardens', 'Temple of Artemis'],
    correctAnswer: 1,
    explanation: 'The Lighthouse of Alexandria (Pharos of Alexandria) was one of the Seven Wonders of the Ancient World, built around 280 BCE.',
    difficulty: 'medium'
  },
  {
    id: 'q10',
    question: 'The Magna Carta was signed in which year?',
    options: ['1215', '1216', '1214', '1217'],
    correctAnswer: 0,
    explanation: 'The Magna Carta was signed in 1215 by King John of England, limiting the power of the monarchy and establishing important legal principles.',
    difficulty: 'medium'
  },
  {
    id: 'q11',
    question: 'Which civilization built Machu Picchu?',
    options: ['Aztec', 'Maya', 'Inca', 'Olmec'],
    correctAnswer: 2,
    explanation: 'Machu Picchu was built by the Inca civilization around 1450 CE, high in the Andes Mountains of Peru.',
    difficulty: 'easy'
  },
  {
    id: 'q12',
    question: 'The Thirty Years\' War primarily took place in which region?',
    options: ['France', 'Holy Roman Empire', 'England', 'Spain'],
    correctAnswer: 1,
    explanation: 'The Thirty Years\' War (1618-1648) was fought primarily in the Holy Roman Empire, devastating much of Central Europe.',
    difficulty: 'hard'
  },
  {
    id: 'q13',
    question: 'Who painted the ceiling of the Sistine Chapel?',
    options: ['Leonardo da Vinci', 'Raphael', 'Michelangelo', 'Donatello'],
    correctAnswer: 2,
    explanation: 'Michelangelo painted the ceiling of the Sistine Chapel between 1508 and 1512, creating one of the most famous artworks in history.',
    difficulty: 'easy'
  },
  {
    id: 'q14',
    question: 'The Opium Wars were fought between China and which country?',
    options: ['France', 'Britain', 'Russia', 'United States'],
    correctAnswer: 1,
    explanation: 'The Opium Wars (1839-1842 and 1856-1860) were fought between China and Britain, resulting in Chinese concessions and the opening of Chinese ports.',
    difficulty: 'medium'
  },
  {
    id: 'q15',
    question: 'Which event is considered the start of World War I?',
    options: ['Sinking of Lusitania', 'Assassination of Archduke Franz Ferdinand', 'German invasion of Belgium', 'Russian mobilization'],
    correctAnswer: 1,
    explanation: 'The assassination of Archduke Franz Ferdinand of Austria-Hungary in Sarajevo on June 28, 1914, is considered the immediate trigger for World War I.',
    difficulty: 'medium'
  },
  {
    id: 'q16',
    question: 'The Code of Hammurabi originated in which ancient civilization?',
    options: ['Egyptian', 'Babylonian', 'Assyrian', 'Persian'],
    correctAnswer: 1,
    explanation: 'The Code of Hammurabi was created by the Babylonian king Hammurabi around 1750 BCE, one of the earliest known legal codes.',
    difficulty: 'hard'
  },
  {
    id: 'q17',
    question: 'Which explorer is credited with "discovering" America for Europeans?',
    options: ['Vasco da Gama', 'Christopher Columbus', 'Ferdinand Magellan', 'Amerigo Vespucci'],
    correctAnswer: 1,
    explanation: 'Christopher Columbus reached the Americas in 1492, though he believed he had reached Asia. His voyages began European colonization of the Americas.',
    difficulty: 'easy'
  },
  {
    id: 'q18',
    question: 'The Berlin Wall fell in which year?',
    options: ['1987', '1988', '1989', '1990'],
    correctAnswer: 2,
    explanation: 'The Berlin Wall fell on November 9, 1989, symbolizing the end of the Cold War and leading to German reunification.',
    difficulty: 'easy'
  },
  {
    id: 'q19',
    question: 'Which ancient Greek philosopher taught Alexander the Great?',
    options: ['Socrates', 'Plato', 'Aristotle', 'Pythagoras'],
    correctAnswer: 2,
    explanation: 'Aristotle was the tutor of Alexander the Great from 343 to 336 BCE, influencing the future conqueror\'s education and worldview.',
    difficulty: 'medium'
  },
  {
    id: 'q20',
    question: 'The Industrial Revolution began in which country?',
    options: ['France', 'Germany', 'Britain', 'United States'],
    correctAnswer: 2,
    explanation: 'The Industrial Revolution began in Britain in the late 18th century, starting with textile manufacturing and steam power.',
    difficulty: 'easy'
  }
];

export const worldRegions: Region[] = [
  {
    id: 'mesopotamia',
    name: 'Mesopotamia',
    x: 48,
    y: 28,
    width: 6,
    height: 8,
    description: 'The "Cradle of Civilization" between the Tigris and Euphrates rivers, birthplace of writing, law, and urban civilization.',
    events: [
      {
        id: 'mesopotamia1',
        title: 'Invention of Writing',
        date: '3200 BCE',
        year: -3200,
        description: 'Cuneiform script developed in Mesopotamia, marking the beginning of recorded history.',
        category: 'invention',
        region: 'Mesopotamia',
        importance: 5
      },
      {
        id: 'mesopotamia2',
        title: 'Code of Hammurabi',
        date: '1750 BCE',
        year: -1750,
        description: 'One of the earliest and most complete legal codes established in Babylon.',
        category: 'empire',
        region: 'Babylon',
        importance: 4
      }
    ]
  },
  {
    id: 'egypt',
    name: 'Ancient Egypt',
    x: 45,
    y: 32,
    width: 4,
    height: 12,
    description: 'Land of the pharaohs, pyramids, and the Nile River. One of history\'s longest-lasting civilizations.',
    events: [
      {
        id: 'egypt1',
        title: 'Unification of Egypt',
        date: '3100 BCE',
        year: -3100,
        description: 'Pharaoh Menes unites Upper and Lower Egypt, founding the first dynasty.',
        category: 'empire',
        region: 'Egypt',
        importance: 5
      },
      {
        id: 'egypt2',
        title: 'Great Pyramid Built',
        date: '2580 BCE',
        year: -2580,
        description: 'The Great Pyramid of Giza is constructed for Pharaoh Khufu.',
        category: 'empire',
        region: 'Egypt',
        importance: 5
      }
    ]
  },
  {
    id: 'greece',
    name: 'Ancient Greece',
    x: 42,
    y: 26,
    width: 8,
    height: 6,
    description: 'Birthplace of democracy, philosophy, and Western civilization. Home to city-states like Athens and Sparta.',
    events: [
      {
        id: 'greece1',
        title: 'First Olympic Games',
        date: '776 BCE',
        year: -776,
        description: 'The first recorded Olympic Games held in Olympia, Greece.',
        category: 'culture',
        region: 'Greece',
        importance: 3
      },
      {
        id: 'greece2',
        title: 'Athenian Democracy',
        date: '508 BCE',
        year: -508,
        description: 'Cleisthenes establishes democracy in Athens.',
        category: 'empire',
        region: 'Greece',
        importance: 5
      },
      {
        id: 'greece3',
        title: 'Battle of Marathon',
        date: '490 BCE',
        year: -490,
        description: 'Greeks defeat the Persians at Marathon.',
        category: 'war',
        region: 'Greece',
        importance: 4
      }
    ]
  },
  {
    id: 'rome',
    name: 'Roman Empire',
    x: 38,
    y: 24,
    width: 15,
    height: 12,
    description: 'One of history\'s greatest empires, spanning from Britain to North Africa and lasting over 1000 years.',
    events: [
      {
        id: 'rome1',
        title: 'Founding of Rome',
        date: '753 BCE',
        year: -753,
        description: 'According to legend, Rome was founded by Romulus and Remus.',
        category: 'empire',
        region: 'Italy',
        importance: 4
      },
      {
        id: 'rome2',
        title: 'Julius Caesar Assassinated',
        date: '44 BCE',
        year: -44,
        description: 'Roman dictator Julius Caesar is assassinated, ending the Roman Republic.',
        category: 'empire',
        region: 'Rome',
        importance: 5
      },
      {
        id: 'rome3',
        title: 'Fall of Western Rome',
        date: '476 CE',
        year: 476,
        description: 'The last Western Roman Emperor is deposed.',
        category: 'empire',
        region: 'Rome',
        importance: 5
      }
    ]
  },
  {
    id: 'china',
    name: 'Ancient China',
    x: 65,
    y: 20,
    width: 18,
    height: 15,
    description: 'One of the world\'s oldest continuous civilizations, known for inventions like paper, gunpowder, and the compass.',
    events: [
      {
        id: 'china1',
        title: 'Qin Dynasty Unifies China',
        date: '221 BCE',
        year: -221,
        description: 'Emperor Qin Shi Huang unifies China and begins the Great Wall.',
        category: 'empire',
        region: 'China',
        importance: 5
      },
      {
        id: 'china2',
        title: 'Tang Dynasty Golden Age',
        date: '618-907 CE',
        year: 618,
        description: 'China\'s Tang Dynasty represents a golden age of culture and prosperity.',
        category: 'empire',
        region: 'China',
        importance: 4
      }
    ]
  },
  {
    id: 'india',
    name: 'Ancient India',
    x: 58,
    y: 28,
    width: 12,
    height: 15,
    description: 'Birthplace of Hinduism and Buddhism, home to great empires like the Maurya and Gupta.',
    events: [
      {
        id: 'india1',
        title: 'Birth of Buddha',
        date: '563 BCE',
        year: -563,
        description: 'Siddhartha Gautama (Buddha) is born, later founding Buddhism.',
        category: 'culture',
        region: 'India',
        importance: 4
      },
      {
        id: 'india2',
        title: 'Mauryan Empire',
        date: '322-185 BCE',
        year: -322,
        description: 'The Mauryan Empire unifies most of the Indian subcontinent.',
        category: 'empire',
        region: 'India',
        importance: 4
      }
    ]
  },
  {
    id: 'persia',
    name: 'Persian Empire',
    x: 50,
    y: 25,
    width: 15,
    height: 10,
    description: 'Vast empire stretching from India to Greece, known for tolerance and efficient administration.',
    events: [
      {
        id: 'persia1',
        title: 'Persian Empire Founded',
        date: '550 BCE',
        year: -550,
        description: 'Cyrus the Great establishes the Persian Empire.',
        category: 'empire',
        region: 'Persia',
        importance: 4
      },
      {
        id: 'persia2',
        title: 'Battle of Thermopylae',
        date: '480 BCE',
        year: -480,
        description: '300 Spartans make their legendary last stand against the Persian army.',
        category: 'war',
        region: 'Greece',
        importance: 4
      }
    ]
  },
  {
    id: 'maya',
    name: 'Maya Civilization',
    x: 15,
    y: 35,
    width: 8,
    height: 10,
    description: 'Advanced Mesoamerican civilization known for astronomy, mathematics, and monumental architecture.',
    events: [
      {
        id: 'maya1',
        title: 'Maya Classical Period',
        date: '250-900 CE',
        year: 250,
        description: 'Maya civilization reaches its peak with great cities like Tikal and Palenque.',
        category: 'empire',
        region: 'Mesoamerica',
        importance: 4
      }
    ]
  },
  {
    id: 'aztec',
    name: 'Aztec Empire',
    x: 12,
    y: 32,
    width: 6,
    height: 8,
    description: 'Powerful Mesoamerican empire centered in Tenochtitlan, conquered by Spanish conquistadors.',
    events: [
      {
        id: 'aztec1',
        title: 'Tenochtitlan Founded',
        date: '1325 CE',
        year: 1325,
        description: 'The Aztecs found their capital city Tenochtitlan on an island in Lake Texcoco.',
        category: 'empire',
        region: 'Mexico',
        importance: 3
      },
      {
        id: 'aztec2',
        title: 'Spanish Conquest',
        date: '1519-1521 CE',
        year: 1519,
        description: 'Hernán Cortés conquers the Aztec Empire.',
        category: 'empire',
        region: 'Mexico',
        importance: 4
      }
    ]
  },
  {
    id: 'inca',
    name: 'Inca Empire',
    x: 20,
    y: 45,
    width: 6,
    height: 12,
    description: 'Largest empire in pre-Columbian America, known for advanced engineering and road systems.',
    events: [
      {
        id: 'inca1',
        title: 'Inca Empire Peak',
        date: '1438-1533 CE',
        year: 1438,
        description: 'The Inca Empire reaches its greatest extent under various rulers.',
        category: 'empire',
        region: 'South America',
        importance: 4
      },
      {
        id: 'inca2',
        title: 'Spanish Conquest',
        date: '1532 CE',
        year: 1532,
        description: 'Francisco Pizarro conquers the Inca Empire.',
        category: 'empire',
        region: 'Peru',
        importance: 4
      }
    ]
  },
  {
    id: 'mongol',
    name: 'Mongol Empire',
    x: 55,
    y: 15,
    width: 25,
    height: 15,
    description: 'Largest contiguous land empire in history, stretching from Eastern Europe to the Pacific Ocean.',
    events: [
      {
        id: 'mongol1',
        title: 'Mongol Empire Founded',
        date: '1206 CE',
        year: 1206,
        description: 'Genghis Khan establishes the Mongol Empire.',
        category: 'empire',
        region: 'Asia',
        importance: 5
      },
      {
        id: 'mongol2',
        title: 'Mongol Conquest of China',
        date: '1279 CE',
        year: 1279,
        description: 'Mongols complete conquest of China, establishing Yuan Dynasty.',
        category: 'empire',
        region: 'China',
        importance: 4
      }
    ]
  },
  {
    id: 'ottoman',
    name: 'Ottoman Empire',
    x: 40,
    y: 22,
    width: 20,
    height: 15,
    description: 'Turkish empire that controlled much of Southeast Europe, Western Asia, and North Africa for over 600 years.',
    events: [
      {
        id: 'ottoman1',
        title: 'Fall of Constantinople',
        date: '1453 CE',
        year: 1453,
        description: 'Ottoman Turks capture Constantinople, ending the Byzantine Empire.',
        category: 'empire',
        region: 'Constantinople',
        importance: 5
      },
      {
        id: 'ottoman2',
        title: 'Siege of Vienna',
        date: '1683 CE',
        year: 1683,
        description: 'Ottoman expansion into Europe is halted at the gates of Vienna.',
        category: 'war',
        region: 'Austria',
        importance: 4
      }
    ]
  }
];