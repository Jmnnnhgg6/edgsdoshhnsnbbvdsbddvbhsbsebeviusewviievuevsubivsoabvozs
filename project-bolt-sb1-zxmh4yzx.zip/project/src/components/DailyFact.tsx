import React from 'react';
import { Calendar, Share2, BookOpen } from 'lucide-react';
import { HistoricalEvent } from '../types';

interface DailyFactProps {
  event: HistoricalEvent;
}

export default function DailyFact({ event }: DailyFactProps) {
  const today = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'war': return 'from-red-500 to-red-600';
      case 'invention': return 'from-blue-500 to-blue-600';
      case 'empire': return 'from-purple-500 to-purple-600';
      case 'culture': return 'from-green-500 to-green-600';
      case 'science': return 'from-cyan-500 to-cyan-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'war': return '⚔️';
      case 'invention': return '💡';
      case 'empire': return '👑';
      case 'culture': return '🎭';
      case 'science': return '🔬';
      default: return '📜';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className={`bg-gradient-to-r ${getCategoryColor(event.category)} p-6 text-white`}>
        <div className="flex items-center gap-3 mb-3">
          <Calendar size={24} />
          <h2 className="text-xl font-bold">This Day in History</h2>
        </div>
        <p className="text-white/90 text-sm">{today}</p>
      </div>

      <div className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="text-4xl">{getCategoryIcon(event.category)}</div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-gray-800 mb-2">{event.title}</h3>
            <p className="text-gray-600 text-sm mb-2">{event.date}</p>
            <p className="text-gray-700">{event.description}</p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span className="px-2 py-1 bg-gray-100 rounded-full">{event.region}</span>
            <span className="px-2 py-1 bg-gray-100 rounded-full capitalize">{event.category}</span>
          </div>
          
          <div className="flex gap-2">
            <button className="flex items-center gap-1 px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
              <BookOpen size={14} />
              Learn More
            </button>
            <button className="flex items-center gap-1 px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-lg transition-colors">
              <Share2 size={14} />
              Share
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}