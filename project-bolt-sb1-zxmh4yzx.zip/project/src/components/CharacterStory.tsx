import React, { useState } from 'react';
import { User, ChevronRight, Award, Calendar } from 'lucide-react';
import { HistoricalFigure, StoryChapter } from '../types';

interface CharacterStoryProps {
  figures: HistoricalFigure[];
}

export default function CharacterStory({ figures }: CharacterStoryProps) {
  const [selectedFigure, setSelectedFigure] = useState<HistoricalFigure>(figures[0]);
  const [currentChapter, setCurrentChapter] = useState<StoryChapter>(figures[0].story[0]);

  const handleFigureSelect = (figure: HistoricalFigure) => {
    setSelectedFigure(figure);
    setCurrentChapter(figure.story[0]);
  };

  const handleChoiceSelect = (nextChapterId: string) => {
    const nextChapter = selectedFigure.story.find(ch => ch.id === nextChapterId);
    if (nextChapter) {
      setCurrentChapter(nextChapter);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 text-white">
        <div className="flex items-center gap-3 mb-3">
          <User size={28} />
          <h2 className="text-2xl font-bold">Historical Characters</h2>
        </div>
        <p className="text-white/90">Experience history through the eyes of legendary figures</p>
      </div>

      <div className="p-6">
        {/* Character Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {figures.map((figure) => (
            <button
              key={figure.id}
              onClick={() => handleFigureSelect(figure)}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                selectedFigure.id === figure.id
                  ? 'border-purple-300 bg-purple-50'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-start gap-3">
                <img
                  src={figure.imageUrl}
                  alt={figure.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800">{figure.name}</h3>
                  <p className="text-sm text-gray-600 mb-1">{figure.title}</p>
                  <p className="text-xs text-gray-500">{figure.period}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Character Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Character Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={selectedFigure.imageUrl}
                alt={selectedFigure.name}
                className="w-20 h-20 rounded-full object-cover border-4 border-purple-200"
              />
              <div>
                <h3 className="text-xl font-bold text-gray-800">{selectedFigure.name}</h3>
                <p className="text-gray-600">{selectedFigure.title}</p>
                <p className="text-sm text-gray-500">{selectedFigure.period}</p>
              </div>
            </div>

            <p className="text-gray-700 text-sm">{selectedFigure.description}</p>

            <div>
              <h4 className="font-semibold text-gray-800 mb-2 flex items-center gap-2">
                <Award size={16} />
                Key Achievements
              </h4>
              <ul className="space-y-1">
                {selectedFigure.achievements.map((achievement, index) => (
                  <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                    <span className="text-purple-500 mt-1">•</span>
                    {achievement}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Interactive Story */}
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-3">
              <Calendar size={16} className="text-gray-600" />
              <span className="text-sm font-medium text-gray-600">
                {Math.abs(currentChapter.year)} {currentChapter.year < 0 ? 'BCE' : 'CE'}
              </span>
            </div>

            <h4 className="font-bold text-gray-800 mb-3">{currentChapter.title}</h4>
            <p className="text-gray-700 text-sm mb-4">{currentChapter.content}</p>

            {currentChapter.choices && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-600 mb-2">What would you do?</p>
                {currentChapter.choices.map((choice) => (
                  <button
                    key={choice.id}
                    onClick={() => handleChoiceSelect(choice.nextChapter)}
                    className="w-full p-3 text-left bg-white rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all text-sm flex items-center justify-between"
                  >
                    <span>{choice.text}</span>
                    <ChevronRight size={16} className="text-gray-400" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}