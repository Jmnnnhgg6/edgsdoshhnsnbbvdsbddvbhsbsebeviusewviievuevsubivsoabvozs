import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Clock, MapPin, Star } from 'lucide-react';
import { TimelinePeriod, HistoricalEvent } from '../types';

interface TimelineProps {
  periods: TimelinePeriod[];
  onEventSelect: (event: HistoricalEvent) => void;
}

export default function Timeline({ periods, onEventSelect }: TimelineProps) {
  const [selectedPeriod, setSelectedPeriod] = useState(periods[0]);
  const [zoomLevel, setZoomLevel] = useState(1);

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.5, 3));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.5, 0.5));

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'war': return '⚔️';
      case 'invention': return '💡';
      case 'empire': return '👑';
      case 'culture': return '🎭';
      case 'science': return '🔬';
      default: return '📜';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Clock className="text-amber-600" size={28} />
          Interactive Timeline
        </h2>
        <div className="flex gap-2">
          <button
            onClick={handleZoomOut}
            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors text-sm"
          >
            Zoom Out
          </button>
          <button
            onClick={handleZoomIn}
            className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors text-sm"
          >
            Zoom In
          </button>
        </div>
      </div>

      {/* Period Selection */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {periods.map((period) => (
          <button
            key={period.id}
            onClick={() => setSelectedPeriod(period)}
            className={`px-4 py-2 rounded-lg font-medium transition-all flex-shrink-0 ${
              selectedPeriod.id === period.id
                ? 'bg-amber-100 text-amber-800 border-2 border-amber-300'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
            style={{
              backgroundColor: selectedPeriod.id === period.id ? `${period.color}20` : undefined,
              borderColor: selectedPeriod.id === period.id ? period.color : undefined
            }}
          >
            {period.name}
            <span className="block text-xs opacity-75">
              {Math.abs(period.startYear)} - {Math.abs(period.endYear)} {period.startYear < 0 ? 'BCE' : 'CE'}
            </span>
          </button>
        ))}
      </div>

      {/* Timeline Visualization */}
      <div className="relative">
        <div 
          className="h-2 bg-gradient-to-r from-gray-200 to-gray-300 rounded-full mb-8"
          style={{ transform: `scaleX(${zoomLevel})`, transformOrigin: 'left' }}
        >
          <div 
            className="h-full rounded-full"
            style={{ 
              background: `linear-gradient(to right, ${selectedPeriod.color}40, ${selectedPeriod.color})`,
              width: '100%'
            }}
          />
        </div>

        {/* Events */}
        <div className="space-y-4">
          {selectedPeriod.events.map((event, index) => (
            <div
              key={event.id}
              className={`bg-gradient-to-r from-white to-gray-50 rounded-lg p-4 border-l-4 cursor-pointer transform transition-all duration-200 hover:scale-105 hover:shadow-md`}
              style={{ borderLeftColor: selectedPeriod.color }}
              onClick={() => onEventSelect(event)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">{getCategoryIcon(event.category)}</span>
                    <h3 className="font-bold text-gray-800">{event.title}</h3>
                    <div className="flex">
                      {Array.from({ length: event.importance }).map((_, i) => (
                        <Star key={i} size={14} className="text-amber-400 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{event.description}</p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span className="font-medium">{event.date}</span>
                    <div className="flex items-center gap-1">
                      <MapPin size={12} />
                      {event.region}
                    </div>
                  </div>
                </div>
                <ChevronRight className="text-gray-400 flex-shrink-0" size={20} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}