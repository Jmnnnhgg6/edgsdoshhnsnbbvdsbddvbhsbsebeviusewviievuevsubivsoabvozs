import React, { useState } from 'react';
import { Brain, CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import { QuizQuestion } from '../types';

interface QuizProps {
  questions: QuizQuestion[];
}

export default function Quiz({ questions }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState<number[]>([]);

  const question = questions[currentQuestion];

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResult) return;
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    const isCorrect = selectedAnswer === question.correctAnswer;
    if (isCorrect && !answeredQuestions.includes(currentQuestion)) {
      setScore(score + 1);
      setAnsweredQuestions([...answeredQuestions, currentQuestion]);
    }
    setShowResult(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnsweredQuestions([]);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const isQuizComplete = currentQuestion === questions.length - 1 && showResult;

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Brain className="text-green-600" size={28} />
          <h2 className="text-2xl font-bold text-gray-800">History Quiz</h2>
        </div>
        <div className="text-sm text-gray-600">
          Question {currentQuestion + 1} of {questions.length}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Progress</span>
          <span>Score: {score}/{questions.length}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-green-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + (showResult ? 1 : 0)) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(question.difficulty)}`}>
            {question.difficulty}
          </span>
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">{question.question}</h3>

        {/* Answer Options */}
        <div className="space-y-3">
          {question.options.map((option, index) => {
            let buttonClass = "w-full p-4 text-left border-2 rounded-lg transition-all ";
            
            if (showResult) {
              if (index === question.correctAnswer) {
                buttonClass += "border-green-300 bg-green-50 text-green-800";
              } else if (index === selectedAnswer && index !== question.correctAnswer) {
                buttonClass += "border-red-300 bg-red-50 text-red-800";
              } else {
                buttonClass += "border-gray-200 bg-gray-50 text-gray-600";
              }
            } else {
              if (selectedAnswer === index) {
                buttonClass += "border-blue-300 bg-blue-50 text-blue-800";
              } else {
                buttonClass += "border-gray-200 hover:border-gray-300 hover:bg-gray-50";
              }
            }

            return (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={buttonClass}
                disabled={showResult}
              >
                <div className="flex items-center justify-between">
                  <span>{option}</span>
                  {showResult && index === question.correctAnswer && (
                    <CheckCircle className="text-green-600" size={20} />
                  )}
                  {showResult && index === selectedAnswer && index !== question.correctAnswer && (
                    <XCircle className="text-red-600" size={20} />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Result Explanation */}
      {showResult && (
        <div className={`p-4 rounded-lg mb-6 ${
          selectedAnswer === question.correctAnswer 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            {selectedAnswer === question.correctAnswer ? (
              <>
                <CheckCircle className="text-green-600" size={20} />
                <span className="font-medium text-green-800">Correct!</span>
              </>
            ) : (
              <>
                <XCircle className="text-red-600" size={20} />
                <span className="font-medium text-red-800">Incorrect</span>
              </>
            )}
          </div>
          <p className="text-sm text-gray-700">{question.explanation}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3">
        {!showResult ? (
          <button
            onClick={handleSubmitAnswer}
            disabled={selectedAnswer === null}
            className="flex-1 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            Submit Answer
          </button>
        ) : (
          <>
            {!isQuizComplete ? (
              <button
                onClick={handleNextQuestion}
                className="flex-1 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
              >
                Next Question
              </button>
            ) : (
              <div className="flex-1 text-center">
                <div className="bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg p-4 mb-3">
                  <h3 className="text-lg font-bold text-gray-800 mb-1">Quiz Complete!</h3>
                  <p className="text-gray-600">Final Score: {score}/{questions.length}</p>
                </div>
                <button
                  onClick={handleRestart}
                  className="flex items-center justify-center gap-2 w-full py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors"
                >
                  <RotateCcw size={20} />
                  Restart Quiz
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}