import React, { useState } from 'react';
import { Globe, Info } from 'lucide-react';
import { Region } from '../types';

interface WorldMapProps {
  regions: Region[];
  onRegionSelect: (region: Region) => void;
}

export default function WorldMap({ regions, onRegionSelect }: WorldMapProps) {
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handleRegionClick = (region: Region) => {
    setSelectedRegion(region);
    onRegionSelect(region);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <Globe className="text-blue-600" size={28} />
        <h2 className="text-2xl font-bold text-gray-800">World History Map</h2>
      </div>

      <div className="relative">
        {/* Simplified World Map SVG */}
        <svg
          viewBox="0 0 100 60"
          className="w-full h-80 bg-gradient-to-b from-blue-100 to-blue-200 rounded-lg border"
        >
          {/* Continents (simplified shapes) */}
          <path
            d="M 10 30 L 25 25 L 30 35 L 20 40 Z"
            fill="#e5e7eb"
            className="continent"
          />
          <path
            d="M 35 20 L 55 15 L 60 30 L 50 35 L 40 30 Z"
            fill="#e5e7eb"
            className="continent"
          />
          <path
            d="M 65 25 L 85 20 L 90 35 L 75 40 Z"
            fill="#e5e7eb"
            className="continent"
          />

          {/* Interactive Regions */}
          {regions.map((region) => (
            <rect
              key={region.id}
              x={region.x}
              y={region.y}
              width={region.width}
              height={region.height}
              fill={hoveredRegion === region.id ? "#fbbf24" : "#f59e0b"}
              stroke="#d97706"
              strokeWidth="0.5"
              className="cursor-pointer transition-all duration-200 hover:opacity-80"
              onMouseEnter={() => setHoveredRegion(region.id)}
              onMouseLeave={() => setHoveredRegion(null)}
              onClick={() => handleRegionClick(region)}
              rx="1"
            />
          ))}

          {/* Region Labels */}
          {regions.map((region) => (
            <text
              key={`label-${region.id}`}
              x={region.x + region.width / 2}
              y={region.y + region.height / 2}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-xs font-medium fill-white pointer-events-none"
              style={{ fontSize: '2px' }}
            >
              {region.name}
            </text>
          ))}
        </svg>

        {/* Legend */}
        <div className="mt-4 flex flex-wrap gap-2">
          {regions.map((region) => (
            <button
              key={region.id}
              onClick={() => handleRegionClick(region)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                selectedRegion?.id === region.id
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {region.name}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Region Info */}
      {selectedRegion && (
        <div className="mt-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-200">
          <div className="flex items-start gap-3">
            <Info className="text-amber-600 flex-shrink-0 mt-1" size={20} />
            <div>
              <h3 className="font-bold text-gray-800 mb-2">{selectedRegion.name}</h3>
              <p className="text-gray-700 text-sm mb-3">{selectedRegion.description}</p>
              
              <div className="space-y-2">
                <h4 className="font-medium text-gray-800">Key Events:</h4>
                {selectedRegion.events.slice(0, 3).map((event) => (
                  <div key={event.id} className="text-sm text-gray-600">
                    <span className="font-medium">{event.date}</span> - {event.title}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}