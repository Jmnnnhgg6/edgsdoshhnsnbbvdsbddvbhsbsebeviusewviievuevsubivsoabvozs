import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Timeline from './components/Timeline';
import DailyFact from './components/DailyFact';
import WorldMap from './components/WorldMap';
import CharacterStory from './components/CharacterStory';
import Quiz from './components/Quiz';
import { timelinePeriods, todaysEvents, worldRegions, historicalFigures, quizQuestions } from './data/historicalData';
import { HistoricalEvent, Region } from './types';

function App() {
  const [currentTab, setCurrentTab] = useState('timeline');
  const [selectedEvent, setSelectedEvent] = useState<HistoricalEvent | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);

  const handleEventSelect = (event: HistoricalEvent) => {
    setSelectedEvent(event);
    // Could open a modal or navigate to detailed view
    console.log('Selected event:', event);
  };

  const handleRegionSelect = (region: Region) => {
    setSelectedRegion(region);
    console.log('Selected region:', region);
  };

  const renderCurrentTab = () => {
    switch (currentTab) {
      case 'timeline':
        return (
          <Timeline 
            periods={timelinePeriods} 
            onEventSelect={handleEventSelect}
          />
        );
      case 'daily':
        return <DailyFact event={todaysEvents[0]} />;
      case 'map':
        return (
          <WorldMap 
            regions={worldRegions} 
            onRegionSelect={handleRegionSelect}
          />
        );
      case 'characters':
        return <CharacterStory figures={historicalFigures} />;
      case 'quiz':
        return <Quiz questions={quizQuestions} />;
      default:
        return (
          <Timeline 
            periods={timelinePeriods} 
            onEventSelect={handleEventSelect}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navigation currentTab={currentTab} onTabChange={setCurrentTab} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {currentTab === 'timeline' && 'Interactive Timeline'}
            {currentTab === 'daily' && 'This Day in History'}
            {currentTab === 'map' && 'Explore World History'}
            {currentTab === 'characters' && 'Historical Figures'}
            {currentTab === 'quiz' && 'Test Your Knowledge'}
          </h2>
          <p className="text-gray-600">
            {currentTab === 'timeline' && 'Journey through time and discover pivotal moments in human history'}
            {currentTab === 'daily' && 'Learn something new about what happened on this day throughout history'}
            {currentTab === 'map' && 'Click on regions to discover their rich historical heritage'}
            {currentTab === 'characters' && 'Experience history through the lives of legendary figures'}
            {currentTab === 'quiz' && 'Challenge yourself with questions about historical events and figures'}
          </p>
        </div>

        {renderCurrentTab()}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-800">Timetrace</h3>
            </div>
            <p className="text-gray-600">
              Bringing history to life through interactive learning experiences
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;