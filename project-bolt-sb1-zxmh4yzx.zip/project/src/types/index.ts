export interface HistoricalEvent {
  id: string;
  title: string;
  date: string;
  year: number;
  description: string;
  category: 'war' | 'invention' | 'empire' | 'culture' | 'science';
  region: string;
  importance: 1 | 2 | 3 | 4 | 5;
}

export interface HistoricalFigure {
  id: string;
  name: string;
  period: string;
  title: string;
  description: string;
  achievements: string[];
  imageUrl: string;
  story: StoryChapter[];
}

export interface StoryChapter {
  id: string;
  title: string;
  content: string;
  year: number;
  choices?: Choice[];
}

export interface Choice {
  id: string;
  text: string;
  nextChapter: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Region {
  id: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  events: HistoricalEvent[];
  description: string;
}

export interface TimelinePeriod {
  id: string;
  name: string;
  startYear: number;
  endYear: number;
  color: string;
  events: HistoricalEvent[];
}